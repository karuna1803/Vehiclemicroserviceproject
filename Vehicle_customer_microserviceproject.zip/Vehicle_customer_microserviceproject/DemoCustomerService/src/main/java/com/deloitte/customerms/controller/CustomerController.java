package com.deloitte.customerms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.deloitte.customerms.entity.Customer;
import com.deloitte.customerms.model.Response;
import com.deloitte.customerms.model.Vehicle;
import com.deloitte.customerms.service.CustomerServiceImpl;

@RestController
@RequestMapping("/customers")
public class CustomerController {
	
	@Autowired
	CustomerServiceImpl customerServiceImpl;
	
	@Autowired
	private RestTemplate resttemp;
	
	@GetMapping("/getCustomers")
	public ResponseEntity<List<Customer>> getAllCustomers()
	{
		List<Customer> customers = customerServiceImpl.getCustomers();
		return new ResponseEntity<List<Customer>>(customers, HttpStatus.OK);
	}
	
	@GetMapping("/getCustomer/{cid}")
	public ResponseEntity<Response> getCustomerbyCId(@PathVariable("cid") Integer id)
	{
		List<Customer> customer = customerServiceImpl.getCustomer(id);
		List<Vehicle> vehicle = resttemp.getForObject("http://localhost:8082/cars/getCar/"+id, List.class);
		Response res = new Response(customer, vehicle);
		return new ResponseEntity<Response>(res, HttpStatus.OK);
		
	}

}
