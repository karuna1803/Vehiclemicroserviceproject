package com.deloitte.customerms.model;

import java.util.List;

import com.deloitte.customerms.entity.Customer;

public class Response
{
	private List<Customer> customerResponse;
	private List<Vehicle> vehicleResponse;
	public Response() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Response(List<Customer> customerResponse, List<Vehicle> vehicleResponse) {
		super();
		this.customerResponse = customerResponse;
		this.vehicleResponse = vehicleResponse;
	}
	public List<Customer> getCustomerResponse() {
		return customerResponse;
	}
	public void setCustomerResponse(List<Customer> customerResponse) {
		this.customerResponse = customerResponse;
	}
	public List<Vehicle> getVehicleResponse() {
		return vehicleResponse;
	}
	public void setVehicleResponse(List<Vehicle> vehicleResponse) {
		this.vehicleResponse = vehicleResponse;
	}
	
	
}
