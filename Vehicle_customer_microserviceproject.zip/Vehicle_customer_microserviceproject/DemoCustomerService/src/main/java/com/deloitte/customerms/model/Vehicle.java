package com.deloitte.customerms.model;

public class Vehicle {
	
	private Integer noplate;
	private String color;
	private String model;
	private String fueltype;
	private Integer cid;
	public Vehicle() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Vehicle(Integer noplate, String color, String model, String fueltype, Integer cid) {
		super();
		this.noplate = noplate;
		this.color = color;
		this.model = model;
		this.fueltype = fueltype;
		this.cid = cid;
	}
	public Integer getNoplate() {
		return noplate;
	}
	public void setNoplate(Integer noplate) {
		this.noplate = noplate;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getFueltype() {
		return fueltype;
	}
	public void setFueltype(String fueltype) {
		this.fueltype = fueltype;
	}
	public Integer getCid() {
		return cid;
	}
	public void setCid(Integer cid) {
		this.cid = cid;
	}
	
	
}
