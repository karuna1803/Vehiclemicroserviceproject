package com.deloitte.customerms.service;

import java.util.List;

import com.deloitte.customerms.entity.Customer;



public interface CustomerService {
	
	public List<Customer> getCustomers();
	public List<Customer> getCustomer(Integer id);

}
