package com.deloitte.carms.service;

import java.util.List;

import com.deloitte.carms.entity.Car;

public interface CarService {
	
	public List<Car> getCars();
	public List<Car> getCar(Integer id);
	

}
