package com.deloitte.carms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.carms.entity.Car;
import com.deloitte.carms.repo.CarRepository;


@Service
public class CarServiceImpl implements CarService {
	
	@Autowired
	CarRepository carRepository;
	

	@Override
	public List<Car> getCars() {
		return carRepository.findAll();
	}


	@Override
	public List<Car> getCar(Integer id) {
		// TODO Auto-generated method stub
		return carRepository.findByCid(id);
	}

	

}
