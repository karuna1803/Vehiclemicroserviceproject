package com.deloitte.carms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deloitte.carms.entity.Car;
import com.deloitte.carms.service.CarServiceImpl;

@RestController
@RequestMapping("/cars")
public class CarController {
	
	@Autowired
	CarServiceImpl carServiceImpl;
	
	@GetMapping("/getCars")
	public ResponseEntity<List<Car>> getAllCars()
	{
		List<Car> cars = carServiceImpl.getCars();
		return new ResponseEntity<List<Car>>(cars, HttpStatus.OK);
	}
	
	@GetMapping("/getCar/{cid}")
	public ResponseEntity<List<Car>> getCarbyCId(@PathVariable("cid") Integer id){
		List<Car> car = carServiceImpl.getCar(id);
		return new ResponseEntity<List<Car>>(car, HttpStatus.OK);
		
	}
	

}
